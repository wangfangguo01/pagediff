/**
 *
 * Created by Ryan on 14-9-4.
 */
/**
 * 显示和隐藏信息
 * */

document.getElementById("URL_button1").onclick = function()
{
    if(flagEdit){
        setOriginal();
    }else{
    addExistProjectURL();
    }
}
document.getElementById("URL_button2").onclick = function()
{
    $("#menuDIV_attribute").animate({top:"-2000px"},"slow");
//    hidden("menuDIV_attribute");
    $('#URL_input0').val('');
    $('#URL_input').val('');
    $('#URL_input2').val('');
    $('#URL_input33').val('');
    $('#URL_input44').val('');
    document.getElementById('divurl1').style.display = 'none';
    document.getElementById('divurl2').style.display = 'none';
    document.getElementById('divurl3').style.display = 'none';
}

document.getElementById("URL_button9").onclick = function()
{

    sendSelectorInfo();

}
document.getElementById("URL_button10").onclick = function()
{
    $("#menuDIV_attribute4").animate({top:"-2000px"},"slow");
    $('#URL_input55').val('');
    $('#URL_input66').val('');

}

document.getElementById("URL_button1").onmousemove = function(){
    document.getElementById("URL_button1").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button1").onmouseout = function(){
    document.getElementById("URL_button1").style.backgroundColor = "#B5B5B5";
}
document.getElementById("URL_button2").onmousemove = function(){
    document.getElementById("URL_button2").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button2").onmouseout = function(){
    document.getElementById("URL_button2").style.backgroundColor = "#B5B5B5";
}
function show(ele)
{
    eval(ele + ".style.display = ''");
}
function hidden(ele)
{
    eval(ele + ".style.display = 'none'");
}
close_div_menu.onclick = function(e)
{
    e.stopPropagation();
    $("#menuDIV_attribute").animate({top:"-2000px"},"slow");
//    hidden("menuDIV_attribute");
    $('#URL_input').val('');

}

/**
 *这里写的是拖动信息
 * */
loginTopDIV.onmousedown = Down;
var tHeight,lWidth;
function Down(e)
{
    var event = window.event || e;
    tHeight = parseInt(menuDIV_attribute.style.top.replace(/px/,""));
    lWidth  = parseInt(menuDIV_attribute.style.left.replace(/px/,""));
    console.log(e);
    document.onmousemove = Move;
    document.onmouseup   = Up;
}
function Move(e) {
    var event = window.event || e;
    var top = tHeight;
    var left = lWidth;
   top = event.clientY;
    left = event.clientX    ;
//判断 top 和 left 是否超出边界
//    top = top < 0 ? 0 : top;
//    top = top > document.body.offsetHeight? document.body.offsetHeight: top;
//    left = left < 0 ? 0 : left;
//    left = left > document.body.offsetWidth - 300 ? document.body.offsetWidth - 300 : left;
    menuDIV_attribute.style.top  = top + "px";
    menuDIV_attribute.style.left = left +"px";
}
function Up() {
    document.onmousemove = null;
}


document.getElementById("URL_button12").onclick = function()
{
    delproject();
}
document.getElementById("URL_button22").onclick = function()
{
    $("#menuDIV_attribute2").animate({top:"-2000px"},"slow");
//    $("#menuDIV_attribute2").css("display","none");
}
document.getElementById("URL_button12").onmousemove = function(){
    document.getElementById("URL_button12").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button12").onmouseout = function(){
    document.getElementById("URL_button12").style.backgroundColor = "#B5B5B5";
}
document.getElementById("URL_button22").onmousemove = function(){
    document.getElementById("URL_button22").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button22").onmouseout = function(){
    document.getElementById("URL_button22").style.backgroundColor = "#B5B5B5";
}
close_div_menu2.onclick = function(e)
{
    e.stopPropagation();
    $("#menuDIV_attribute2").animate({top:"-2000px"},"slow");
//    $("#menuDIV_attribute2").css("display","none");


}


document.getElementById("URL_button3").onclick = function()
{
    submitEditProduct();

}
document.getElementById("URL_button4").onclick = function()
{
    $("#menuDIV_attribute3").animate({top:"-2000px"},"slow");
//    hidden("menuDIV_attribute");
    $('#URL_input3').val('');
    $('#URL_input4').val('');
}
document.getElementById("URL_button5").onclick = function()
{
//    $("#menuDIV_attribute3").animate({top:"-2000px"},"slow");
//    $('#URL_input3').val('');
//    $('#URL_input4').val('');
    switchDIV("to");
}
document.getElementById("URL_button3").onmousemove = function(){
    document.getElementById("URL_button3").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button3").onmouseout = function(){
    document.getElementById("URL_button3").style.backgroundColor = "#B5B5B5";
}
document.getElementById("URL_button4").onmousemove = function(){
    document.getElementById("URL_button4").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button4").onmouseout = function(){
    document.getElementById("URL_button4").style.backgroundColor = "#B5B5B5";
}
document.getElementById("URL_button5").onmousemove = function(){
    document.getElementById("URL_button5").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button5").onmouseout = function(){
    document.getElementById("URL_button5").style.backgroundColor = "#B5B5B5";
}

document.getElementById("URL_button7").onmousemove = function(){
    document.getElementById("URL_button7").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button7").onmouseout = function(){
    document.getElementById("URL_button7").style.backgroundColor = "#B5B5B5";
}
document.getElementById("URL_button8").onmousemove = function(){
    document.getElementById("URL_button8").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button8").onmouseout = function(){
    document.getElementById("URL_button8").style.backgroundColor = "#B5B5B5";
}

document.getElementById("URL_button9").onmousemove = function(){
    document.getElementById("URL_button9").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button9").onmouseout = function(){
    document.getElementById("URL_button9").style.backgroundColor = "#B5B5B5";
}
document.getElementById("URL_button10").onmousemove = function(){
    document.getElementById("URL_button10").style.backgroundColor = "#8A8A8A";
}
document.getElementById("URL_button10").onmouseout = function(){
    document.getElementById("URL_button10").style.backgroundColor = "#B5B5B5";
}