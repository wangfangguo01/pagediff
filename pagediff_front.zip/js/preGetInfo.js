/**
 * Created by ryan on 14-9-28.
 */

//获取右侧已存在的project_name
(function getProjectName(){
    var post_path = PATH + "getproject";
    var str = '';
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            $('#pro_product').empty();
            existProjectName = [];
            $.each(call_data.project,function(i,val){
                existProjectName.push(call_data.project[i].name);
                $('#pro_product').append('<li class="list-group-item">' +
                    '<div class="pull-right m-l"><!--<a href="#" class="m-r-sm">-->' +
                    '<!--<i class="icon-cloud-download"></i></a>-->' +
                    '<a class="m-r-sm po2" onclick="editProduct(this)"><i class="icon-pencil"></i></a>' +
                    '<a class="po2" onclick="controlDelMenue(this.parentNode.parentNode.lastChild.firstChild.firstChild.innerText)"><i class="icon-close"></i></a></div>' +
                    '<span class="m-r-sm pull-left"><i class="icon-control-play text"></i></span>' +
                    '<div class="clear text-ellipsis"><a href="#'+call_data.project[i].name+'" class="m-r-sm" onclick="getProjectInfo(this.text);highlight(this)"><span>'+call_data.project[i].name+'</span></a>' +
                    '<p class="text-muted">'+call_data.project[i].desc+'</p></div></li>');

            });

            if(fp){
                huifuProdectMenue();
                returnWelcome();
            }
            fp=true;
            if(ffgl){
                onloadpage();
                ffgl=false;
            }

        },
        'json'
    );

})();