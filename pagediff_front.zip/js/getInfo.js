/**
 * Created by Ryan on 14-9-2.
 */

//接口地址
var PATH = 'http://cq01-testing-hao123-24.vm.baidu.com:8080/';
//var PATH = 'http://172.22.65.10:8080/';
//存放所有已存在的project_name
var existProjectName = new Array();
//当前选中的project名称
var selectProjectName;
//当前显示的image number
var image_num = 0;
//控制修改
var flagEdit = false;
//控制添加已存在的page
var flagaddUrl = true;
//存储page页面的excludeSelector
var excludeSelectors_temp = new Array();
//存储page页面的includeSelector
var includeSelectors_temp = new Array();


var thisTemp = null;
var tempeditorProduct = null;
var fp = true;
var dfp = true;
var email_temp = new Array();
var ffgl=true;
var tempEmail = new Array();
var editProjectNameTemp;
var pagenameTemp2;

//获取右侧已存在的project_name
function getProjectName(){
    var post_path = PATH + "getproject";
    var str = '';
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            $('#pro_product').empty();
            existProjectName = [];
            $.each(call_data.project,function(i,val){
                existProjectName.push(call_data.project[i].name);
                $('#pro_product').append('<li class="list-group-item">' +
                    '<div class="pull-right m-l"><!--<a href="#" class="m-r-sm">-->' +
                    '<!--<i class="icon-cloud-download"></i></a>-->' +
                    '<a class="m-r-sm po2" onclick="editProduct(this)"><i class="icon-pencil"></i></a>' +
                    '<a class="po2" onclick="controlDelMenue(this.parentNode.parentNode.lastChild.firstChild.firstChild.innerText)"><i class="icon-close"></i></a></div>' +
                    '<span class="m-r-sm pull-left"><i class="icon-control-play text"></i></span>' +
                    '<div class="clear text-ellipsis"><a href="#'+call_data.project[i].name+'" class="m-r-sm" onclick="getProjectInfo(this.text);highlight(this)"><span>'+call_data.project[i].name+'</span></a>' +
                    '<p class="text-muted">'+call_data.project[i].desc+'</p></div></li>');

            });

            if(fp){
                huifuProdectMenue();
                returnWelcome();
            }
            fp=true;
            if(ffgl){
                onloadpage();
                ffgl=false;
            }

        },
        'json'
    );

}

//时间格式化 毫秒转时间
function mmSecondTOtime(time, format){
        var t = new Date(time);
        var tf = function(i){return (i < 10 ? '0' : '') + i};
        return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function(a){
            switch(a){
                case 'yyyy':
                    return tf(t.getFullYear());
                    break;
                case 'MM':
                    return tf(t.getMonth() + 1);
                    break;
                case 'mm':
                    return tf(t.getMinutes());
                    break;
                case 'dd':
                    return tf(t.getDate());
                    break;
                case 'HH':
                    return tf(t.getHours());
                    break;
                case 'ss':
                    return tf(t.getSeconds());
                    break;
            }
        })
}


//高亮
function highlight(obj){
    var li = obj.parentNode.parentNode.parentNode.children;
    $.each(li,function(i,val){
        val.className = 'list-group-item';
    });

    obj.parentNode.parentNode.className="list-group-item active";
}

//点击左侧已存在的project所进行的操作
function getProjectInfo(projectName){
    excludeSelectors_temp=[];
    includeSelectors_temp=[];
    controlTOInfo('history');
    setDIVHeight();
    controlExistDiv();
    selectProjectName = projectName;
    $('#main_table').empty();
    //table具体内容
    var str = '{"name":"'+projectName+'"}';
    var post_path = PATH + "getprojectinfo";
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            $.each(call_data.page,function(i,val){

                    excludeSelectors_temp.push(call_data.page[i]);
                    includeSelectors_temp.push(call_data.page[i]);
//            for(var i = call_data.page.length - 1;i>=0;i--){

                $('#main_table').append('<tr><td><label class="checkbox m-n i-checks">' +
                    '<input type="checkbox" name="post[]"><i></i></label>' +
                    '</td><td>'+call_data.page[i].pagename+'</td>' +
                    '<td>'+call_data.page[i].urlnew+'</td>' +
                    '<td>'+call_data.page[i].urlold+'</td><td>'+mmSecondTOtime(call_data.page[i].lastactiontime, 'yyyy/MM/dd HH:mm:ss')+'</td>' +
//                    '<td>&nbsp;<a href="#" onclick="dfp=true;thisTemp=this;flagEdit=true;controlURLMenue(this)"><i class="fa fa-pencil text-success text" title="edit"></i></a>&nbsp;&nbsp;&nbsp;' +
                    '<td>&nbsp;<a href="#'+selectProjectName+'" onclick="actionfun(this)"><i class="fa fa-caret-square-o-right text-success text po2" title="build"></i></a>&nbsp;&nbsp;&nbsp;' +
//                    '<a href="#" onclick="controlShowImage(this.parentNode.parentNode)"><i class="fa fa-file text-success text" title="view"></i></a>&nbsp;&nbsp;&nbsp;' +
                    '<a href="#'+selectProjectName+'&'+call_data.page[i].pagename+'" onclick="historyDiv(this.parentNode.parentNode.childNodes[1].innerText)"><i class="fa fa-clock-o text-success text" title="history"></i></a>' +
                    '&nbsp;&nbsp;&nbsp;<a href="#'+selectProjectName+'" onclick="editSelectors(this)"><i class="fa fa-pencil text-success text po2" title="edit"></i></a>' +
                    '&nbsp;&nbsp;&nbsp;<a href="#'+selectProjectName+'" onclick="delExistProjectURL(this.parentNode.parentNode)"><i class="fa fa-times text-danger text" title="delete"></i></a></td></tr>');
//            }
            });

        },
        'json'
    );

    $('#addProject').css("display","none");
    $('#existProject').css("display","");

    $("#exist_div_2").animate({left:"200000px"},"normal");
    $("#exist_div_2").css("display","none");
    $("#bjax-target").css("display","");
    $("#bjax-target").animate({left:"0px"},"normal");

    $('#bjax-target').find("input")[0].checked=false;


}

//重复刷新selectors的信息，不刷新页面，仅刷新变量
function refreshSelectors(projectName){
    var str = '{"name":"'+projectName+'"}';
    var post_path = PATH + "getprojectinfo";
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            excludeSelectors_temp=[];
            includeSelectors_temp=[];
            $.each(call_data.page,function(i,val){

                excludeSelectors_temp.push(call_data.page[i]);
                includeSelectors_temp.push(call_data.page[i]);

            });

        },
        'json'
    );
}

//新增一个project
function addProject(){
    var flag_add = true;
    var flag_add2 = true;
    var flag_add3 = true;
    //检查参数格式
    var xobj = $("#add_project_table_1").children();

    flag_add = checkExistProjectName(xobj.find("input")[0].value);
//    flag_add2 = checkDesc(xobj.find("input")[1].value);
    if(flag_add){
        for(var j=1;j<xobj.find("input").length;j++){
            flag_add =  checkURL(xobj.find("input")[j]);
            if(flag_add == false){
                break;
            }
        }

        for(var j=2;j<xobj.find("input").length;j=j+3){
            flag_add3 =  checkPagename(xobj.find("input")[j]);
            if(flag_add3 == false){
                break;
            }
        }
    }

    for(var j=1;j<xobj.find("input").length;j++){
        checkURL(xobj.find("input")[j]);
    }

    for(var j=2;j<xobj.find("input").length;j=j+3){
        checkPagename(xobj.find("input")[j]);
    }

    if(flag_add&&flag_add3){
        var obj = $("#add_project_table_1").children().children().find("input");

        var project_name = obj[0].value;
        var desc = obj[1].value;
        var urls = '';
        for(var i=2;i<obj.length;i=i+3){
            urls = urls + '{"pagename":"'+obj[i].value+'","urlold":"'+obj[i+1].value+'","urlnew":"'+obj[i+2].value+'"},'
//            urls = urls + '"' + obj[i].value + '",';
        }
        urls = urls.substring(0,urls.length-1);

        var email = '';
        if(email_temp.length==0){

        }else{
            if(email_temp.length==1&&email_temp[0]==''){
                email='';
            }else{
                for(var j=0;j<email_temp.length;j++){
                    email = email + '"'+email_temp[j]+'",'
                }
                email = email.substring(0,email.length-1);
            }
        }

        var str = '{"name":"'+project_name+'","desc":"'+desc+'","url":['+urls+'],"email":['+email+']}';
        var post_path = PATH + "create";
//        console.log(str);
        str = encodeURI(str);
        $.get(post_path,
            str,
            function(call_data){
                if(call_data.status=="success"){
                    fp=false;
                    getProjectName();
                    alert('添加成功');
                    initCreate();
                }
            },
            'json'
        );

    }
}


//初始化create页面
function initCreate(){
    email_temp = [];
    var s = $('#add_project_table_1').children().find('input');
    s[0].value = '';
    s[1].value = '';
    s[2].value = '';
    s[3].value = '';
    s[4].value = '';
    $("#right_span").css("display","none");
    $('#exist_leable_span').css("display","none");
    $("#right_span7").css("display","none");
    $('#exist_leable_span7').css("display","none");
    $('#ppw').removeClass("has-success");
    $('#ppw').removeClass("has-error");
    $('#ppw2').removeClass("has-success");
    $('#ppw2').removeClass("has-error");

    $("#right_span0").css("display","none");
    $("#right_span22").css("display","none");
    $('#exist_leable_span22').css("display","none");
    $("#right_span2").css("display","none");
    $('#exist_leable_span2').css("display","none");
    $('#exist_leable_span0').css("display","none");
    $('#n1').removeClass("has-success");
    $('#n2').removeClass("has-error");
    $('#n2').removeClass("has-success");
    $('#n1').removeClass("has-error");
    $('#n0').removeClass("has-success");
    $('#n0').removeClass("has-error");
    var l = $('#add_project_table_1').children().length;
    if(l>2){
        var ob = $('#add_project_table_1').children();
        for(var i=2;i<l-1;i++){
            ob[i].remove();
        }
    }
}

//点击新增project切换页面
function addProject_pre(){
    $('#existProject').css("display","none");
    $('#addProject').css("display","block");
}


//构建
function actionfun(obj){
    var pagename = obj.parentNode.parentNode.childNodes[1].innerText;
    var str = '{"name":"'+selectProjectName+'","pagename":"'+pagename+'"}';
    var post_path = PATH + "action";
//    console.log(str);
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            if(call_data.status=='success'){
                alert("成功触发构建");
            }

        },
        'json'
    );
}

//检查existProjectName是否已存在
function checkExistProjectName(newName){
    var flag = true;
    for(var i=0;i<existProjectName.length;i++){
        if(existProjectName[i]==newName){
            $("#right_span").css("display","none");
            $('#exist_leable_span').css("display","");
            $('#ppw').removeClass("has-success");
            $('#ppw').removeClass("has-error");
            $('#ppw').addClass("col-lg-2 has-error");
            flag = false;
            return false;
        }
    }
    if(flag){
        if(newName==''||newName==null||newName.indexOf(' ')==0||newName.indexOf('#')>=0||newName.indexOf('&')>=0){
            $('#exist_leable_span').css("display","");
            $('#right_span').css("display","none");
            $('#ppw').removeClass("has-success");
            $('#ppw').removeClass("has-error");
            $('#ppw').addClass("col-lg-2 has-error");
            return false;
        }else{
            $('#exist_leable_span').css("display","none");
            $('#right_span').css("display","");
            $('#ppw').removeClass("has-success");
            $('#ppw').removeClass("has-error");
            $('#ppw').addClass("col-lg-2 has-success");
            return true;
        }

    }
}


//检查desc合法性
function checkDesc(newName){
    if(newName==''||newName==null||newName.indexOf(' ')==0){
        $('#exist_leable_span7').css("display","");
        $('#right_span7').css("display","none");
        $('#ppw2').removeClass("has-success");
        $('#ppw2').removeClass("has-error");
        $('#ppw2').addClass("col-lg-2 has-error");
        return false;
    }else{
        $('#exist_leable_span7').css("display","none");
        $('#right_span7').css("display","");
        $('#ppw2').removeClass("has-success");
        $('#ppw2').removeClass("has-error");
        $('#ppw2').addClass("col-lg-2 has-success");
        return true;
    }
}


//检查新添加的URL的格式
function checkURL(obj){
    if(obj.value==''||obj.value==null||obj.value.indexOf(' ')==0){
        obj.parentNode.children[2].style.display = 'none';
        obj.parentNode.children[1].style.display = '';
        obj.parentNode.className="col-lg-2 has-success";
        obj.parentNode.className="col-lg-2 has-error";
        obj.parentNode.className="col-lg-2 has-error";

        return false;
    }else{
        obj.parentNode.children[1].style.display = 'none';
        obj.parentNode.children[2].style.display = '';
        obj.parentNode.className="col-lg-2 has-success";
        obj.parentNode.className="col-lg-2 has-error";
        obj.parentNode.className="col-lg-2 has-success";
        return true;
    }

}


//检查pagename合法性
function checkPagename(obj){
    if(obj.value==''||obj.value==null||obj.value.indexOf(' ')==0||obj.value.indexOf('&')==0||obj.value.indexOf('#')==0){
        obj.parentNode.children[2].style.display = 'none';
        obj.parentNode.children[1].style.display = '';
        obj.parentNode.className="col-lg-2 has-success";
        obj.parentNode.className="col-lg-2 has-error";
        obj.parentNode.className="col-lg-2 has-error";

        return false;
    }else{
        var flag = true;
        var objx = $("#add_project_table_1").children().children().find("input");
        var page_name = objx[2].value;
        var p = 0;
        for(var i=2;i<objx.length;i=i+3){
            if(objx[i].value==obj.value){
                p++;
                if(p==2){
                    flag = false;
                    break;
                }

            }
        }

        if(flag){
            obj.parentNode.children[1].style.display = 'none';
            obj.parentNode.children[2].style.display = '';
            obj.parentNode.className="col-lg-2 has-success";
            obj.parentNode.className="col-lg-2 has-error";
            obj.parentNode.className="col-lg-2 has-success";
            return true;
        }else{
            obj.parentNode.children[2].style.display = 'none';
            obj.parentNode.children[1].style.display = '';
            obj.parentNode.className="col-lg-2 has-success";
            obj.parentNode.className="col-lg-2 has-error";
            obj.parentNode.className="col-lg-2 has-error";
            return false;
        }

    }
}


//删除URL
function delURL(obj){
    obj.parentNode.parentNode.remove();
}


//新增URL
function addURL(){

    $("#submitBUtton").before('<div class="form-group">' +
        '<label class="col-lg-2 control-label">Page_name</label>' +
        '<div class="col-lg-2" id="n10">' +
        '<input type="text" class="form-control" placeholder="Page_name" onblur="checkPagename(this)">' +
        '<span class="help-block m-b-none" style="display: none" id="exist_leable_span0">格式不合法或已存在</span>' +
        '<span class="help-block m-b-none" style="display: none" id="right_span0">正确</span></div>' +
        '<label class="col-lg-1 control-label">URL_old</label>' +
        '<div class="col-lg-2">' +
        '<input type="text" class="form-control" placeholder="www.baidu.com" onblur="checkURL(this)">' +
        '<span class="help-block m-b-none" style="display: none">输入格式不合法</span>' +
        '<span class="help-block m-b-none" style="display: none">正确</span>' +
        '</div><label class="col-lg-1 control-label">URL_new</label>' +
        '<div class="col-lg-2">' +
        '<input type="text" class="form-control" placeholder="www.baidu.com" onblur="checkURL(this)">' +
        '<span class="help-block m-b-none" style="display: none" >输入格式不合法</span>' +
        '<span class="help-block m-b-none" style="display: none" >正确</span></div>' +
        '<a href="#" class="pull-right" onclick="" style="margin-bottom: 10px">' +
        '<i class="fa fa-trash-o i-lg  inline" style="margin-right: 20px" onclick="delURL(this)"></i></a></div>');



}


//新增email
function addEmail(){
    var x = $('#add_project_table_2').children().length;
    if(x<15){

    $("#submitBUtton2").before('<div class="form-group">' +
        '<label class="col-lg-2 control-label">Email</label>' +
        '<div class="col-lg-4" >' +
        '<input type="text" class="form-control" placeholder="xxx@xxx" onblur="checkEmail(this)">' +
        '<span class="help-block m-b-none" style="display: none" >不能为空或格式不正确</span>' +
        '</div>' +
        '<a href="#" class="pull-right " onclick="this.parentNode.remove()" style="margin-bottom: 10px">' +
        '<i class="fa fa-trash-o i-lg  inline" style="margin-right: 20px" ></i>' +
        '</a>' +
        '</div>');
    }
}


//向已有的project中添加page
function addExistProjectURL(){
    var fl = true;
    checkExistPagename($('#URL_input0').val());
    if(flagaddUrl==false){
        fl = false;
    }
    checkURlfun($('#URL_input').val(),'divurl2');
    if(flagaddUrl==false){
        fl = false;
    }
    checkURlfun($('#URL_input2').val(),'divurl3');
    if(flagaddUrl==false){
        fl = false;
    }
    if(fl){

    var pagename = $('#URL_input0').val();
    var urlTemp = $('#URL_input').val();
    var urlTemp2 = $('#URL_input2').val();
    var urlTemp3 = $('#URL_input33').val();
    var urlTemp4 = $('#URL_input44').val();


    if(urlTemp3.indexOf(",")>0){
        var arr = new Array();
        arr = urlTemp3.split(",");
        urlTemp3='';
        for(var i=0;i<arr.length;i++){
            urlTemp3+='"'+arr[i]+'",';
        }
        urlTemp3 = urlTemp3.substring(0,urlTemp3.length-1);
    }else{
        if(!urlTemp3==''){
            urlTemp3 = '"'+urlTemp3+'"';
        }

    }
    if(urlTemp4.indexOf(",")>0){
            var arr = new Array();
            arr = urlTemp4.split(",");
            urlTemp4='';
            for(var i=0;i<arr.length;i++){
                urlTemp4+='"'+arr[i]+'",';
            }
            urlTemp4 = urlTemp4.substring(0,urlTemp4.length-1);
    }else{
        if(!urlTemp4==''){
            urlTemp4 = '"'+urlTemp4+'"';
        }

    }
    if(urlTemp==''||urlTemp==null||urlTemp.indexOf(' ')==0||urlTemp2==''||urlTemp2==null||urlTemp2.indexOf(' ')==0){

    }else{

    var str = '{"name":"'+selectProjectName+'","pagename":"'+pagename+'","urlold":"'+urlTemp+'","urlnew":"'+urlTemp2+'","excludeSelectors":['+urlTemp3+'],"includeSelectors":['+urlTemp4+']}';
    var post_path = PATH + "addpage";
        console.log(str);
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            if(call_data.status=='success'){
//                 $('#main_table').append('<tr><td><input type="checkbox"  class="check"/></td><td>'+selectProjectName+'</td><td class="title"><a href="#">'+urlTemp+'</a></td><td class="i-operate"><a href="#" title="查看">查看</a>&nbsp;<a href="#" title="删除" onclick="delExistProjectURL(this.parentNode.parentNode)">删除</a></td></tr>');
//                $('#main_table').append('<tr><td><label class="checkbox m-n i-checks">' +
//                    '<input type="checkbox" name="post[]"><i></i></label>' +
//                    '</td><td>'+selectProjectName+'</td><td>'+urlTemp2+'</td><td>'+urlTemp+'</td><td><a href="#" onclick="thisTemp=this;flagEdit=true;controlURLMenue(this)"><i class="fa fa-pencil text-success text" title="edit"></i></a>&nbsp;&nbsp;&nbsp;' +
//                    '<a href="#" onclick="controlShowImage(this.parentNode.parentNode)"><i class="fa fa-file text-success text" title="view"></i></a>' +
//                    '&nbsp;&nbsp;&nbsp;<a href="#" onclick="delExistProjectURL(this.parentNode.parentNode)"><i class="fa fa-times text-danger text" title="delete"></i></a></td></tr>');


                $('#main_table').append('<tr><td><label class="checkbox m-n i-checks">' +
                    '<input type="checkbox" name="post[]"><i></i></label>' +
                    '</td>' +
                    '<td>'+pagename+'</td><td>'+urlTemp2+'</td><td>'+urlTemp+'</td>' +
                    '<td>'+mmSecondTOtime(call_data.lastactiontime,"yyyy/MM/dd HH:mm:ss")+'</td>' +
//                    '<td>&nbsp;<a href="#" onclick="dfp=true;thisTemp=this;flagEdit=true;controlURLMenue(this)"><i class="fa fa-pencil text-success text" title="edit"></i></a>&nbsp;&nbsp;&nbsp;' +
                    '<td>&nbsp;<a href="#'+selectProjectName+'" class="po2" onclick="actionfun(this)"><i class="fa fa-caret-square-o-right text-success text" title="build"></i></a>&nbsp;&nbsp;&nbsp;' +
//                    '<a href="#" onclick="controlShowImage(this.parentNode.parentNode)"><i class="fa fa-file text-success text" title="view"></i></a>&nbsp;&nbsp;&nbsp;' +
                    '<a href="#'+selectProjectName+'&'+pagename+'" onclick="historyDiv(this.parentNode.parentNode.childNodes[1].innerText)"><i class="fa fa-clock-o text-success text" title="history"></i></a>' +
                    '&nbsp;&nbsp;&nbsp;<a href="#'+selectProjectName+'" onclick="editSelectors(this)"><i class="fa fa-pencil text-success text po2" title="edit"></i></a>' +
                    '&nbsp;&nbsp;&nbsp;<a href="#'+selectProjectName+'" onclick="delExistProjectURL(this.parentNode.parentNode)"><i class="fa fa-times text-danger text" title="delete"></i></a></td></tr>');

                refreshSelectors(selectProjectName);

                $("#menuDIV_attribute").animate({top:"-2000px"},"slow");
                $('#URL_input0').val('');
                $('#URL_input').val('');
                $('#URL_input2').val('');
                $('#URL_input33').val('');
                $('#URL_input44').val('');
                document.getElementById('divurl1').style.display = 'none';
                document.getElementById('divurl2').style.display = 'none';
                document.getElementById('divurl3').style.display = 'none';

            }

        },
        'json'
    );

    }
    }
    flagaddUrl=true;
}


//删除已存在的项目中的url
function delExistProjectURL(obj){
    var urlTemp = obj.children[1].innerText;
    var str = '{"name":"'+selectProjectName+'","pagename":"'+urlTemp+'"}';
    var post_path = PATH + "delpage";
//    console.log(str);
    $.get(post_path,
        str,
        function(call_data){
            if(call_data.status=='success'){
                obj.remove();
                refreshSelectors(selectProjectName);
            }

        },
        'json'
    );

}


//删除已存在的project
function delproject(){
    var str = '{"name":"'+selectProjectName+'"}';
    var post_path = PATH + "delproject";
//    console.log(str);
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            if(call_data.status=='success'){
                fp=false;
                getProjectName();
                $('#main_table').empty();
                $("#menuDIV_attribute2").animate({top:"-2000px"},"slow");
            }

        },
        'json'
    );

}


//控制展示图片
function controlShowImage(obj){
    var pagename = obj.children[1].innerText;
    var time = obj.children[5].innerText;
    time = (new Date(time)).getTime();
    var str = '{"name":"'+selectProjectName+'","pagename":"'+pagename+'","time":"'+time+'"}';
    var post_path = PATH + "getpagehistoryinfo";
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);

            if(call_data.status=='success'){
                image_num = 0;

                    $('#im1')[0].src="data:image/png;base64,"+call_data.diff;
                    $('#im2')[0].src="data:image/png;base64,"+call_data.pre;
                    $('#im3')[0].src="data:image/png;base64,"+call_data.now;
                $('#trunaroundicon').css("display","none");
                $('#adivxy').css("display","");
                $('#diffbutton').attr("onclick","diffImage()");
                $('#oldbutton').attr("onclick","oldImage()");
                $('#newbutton').attr("onclick","newImage()");

            }

        },
        'json'
    );
    huifuProdectMenue();

    $("#bjax-target").animate({left:"200000px"},"slow");
    $("#bjax-target").css("display","none");
    $("#exist_div_2").css("display","");
    $("#exist_div_2").animate({left:"0px"},"slow");
}


//设置截图初始对比图
function setOriginal(){
    var fl = true;
    checkExistPagename($('#URL_input0').val());
    if(flagaddUrl==false){
        fl = false;
    }
    checkURlfun($('#URL_input').val(),'divurl2');
    if(flagaddUrl==false){
        fl = false;
    }
    checkURlfun($('#URL_input2').val(),'divurl3');
    if(flagaddUrl==false){
        fl = false;
    }
    if(fl){

    var pageNew =  $("#URL_input2").val();
    var pageold =  $("#URL_input").val();
    var pagename =  $("#URL_input0").val();

    var str = '{"name":"'+selectProjectName+'","url":[{"pagename":"'+pagename+'","urlold":"'+pageold+'","urlnew":"'+pageNew+'"}]}';
    var post_path = PATH + "setting";
//    console.log(str);
    $.get(post_path,
        str,
        function(call_data){
            if(call_data.status=='success'){
                thisTemp.parentNode.parentNode.childNodes[1].innerText = pagename;
                thisTemp.parentNode.parentNode.childNodes[2].innerText = pageNew;
                thisTemp.parentNode.parentNode.childNodes[3].innerText = pageold;
                $("#menuDIV_attribute").animate({top:"-2000px"},"slow");
                $('#URL_input0').val('');
                $('#URL_input').val('');
                $('#URL_input2').val('');
                document.getElementById('divurl1').style.display = 'none';
                document.getElementById('divurl2').style.display = 'none';
                document.getElementById('divurl3').style.display = 'none';
            }

        },
        'json'
    );

    }
    flagaddUrl=true;

}


//查找已存在的pagename
function checkExistPagename(obj){

    if($('#URL_input0').val()==''||$('#URL_input0').val().indexOf(' ')==0){
        document.getElementById('divurl1').style.display = '';
        flagaddUrl = false;
    }else{
        flagaddUrl = true;
    }

    var len = $('#main_table').find('tr').length;
    for(var i=0;i<len;i++){
//        console.log(1);
        if($('#main_table').find('tr')[i].children[1].innerText==obj){
            document.getElementById('divurl1').style.display = '';
            flagaddUrl = false;
            break;
        }
    }
    if(flagaddUrl){
        document.getElementById('divurl1').style.display = 'none';
    }
    if(temp2pagename==obj&&dfp){
        flagaddUrl = true;
        document.getElementById('divurl1').style.display = 'none';
    }

}


//检查url格式
function checkURlfun(obj,id1){
    if(obj==''||obj.indexOf(' ')==0){
        document.getElementById(id1).style.display = '';
        flagaddUrl = false;
    }else{
        flagaddUrl = true;
        document.getElementById(id1).style.display = 'none';
    }
}


//控制切换回详细信息页面
function controlTOInfo(str){
    document.getElementById('sidebar2').style.display = '';

    $("#sidebar2").animate({left:"0px"},"normal");
    setTimeout(function(){    document.getElementById('sidebar2').style.zIndex = '0';
    },800);
    $("#exist_div_2").animate({left:"200000px"},"normal");
    $("#exist_div_2").css("display","none");

    if(str=='image'){
        $("#bjax-target").animate({left:"200000px"},"normal");
        $("#bjax-target").css("display","none");
        $("#bjax-target90").css("display","");
        $("#bjax-target90").animate({left:"0px"},"normal");

        $('#trunaroundicon').css("display","");
        $('#im1')[0].src="";
        $('#im2')[0].src="";
        $('#im3')[0].src="";

    }else{

    $("#bjax-target90").animate({left:"200000px"},"normal");
    $("#bjax-target90").css("display","none");
    $("#bjax-target").css("display","");
    $("#bjax-target").animate({left:"0px"},"normal");
    }

}


//控制显示添加界面div
function controlADDDiv(){
    //初始化add页面
    document.getElementById('welcome').style.display = 'none';

    initCreate();
    huifuProdectMenue();
    returnEmailDiv();

    $('#sp1').css("display","none");
    $('#hk').removeClass("has-success");
    $('#hk').removeClass("has-error");

    $('#email1').val('');
    var l = $('#add_project_table_2').children().length;
    if(l>1){
        var ob = $('#add_project_table_2').children();
        for(var i=1;i<l-1;i++){
            ob[i].remove();
        }
    }


    $("#exist_div_2").animate({left:"200000px"},"fast");
    $("#exist_div_2").css("display","none");
    $("#bjax-target").animate({left:"200000px"},"fast");
    $("#bjax-target").css("display","none");
    $("#exist_div_3").css("display","");
    $("#exist_div_3").animate({left:"0px"},"fast");
}


//控制显示已存在项目div
function controlExistDiv(){
    document.getElementById('welcome').style.display = 'none';
    $("#exist_div_2").animate({left:"200000px"},"normal");
    $("#exist_div_2").css("display","none");
    $("#exist_div_3").animate({left:"200000px"},"normal");
    $("#exist_div_3").css("display","none");
    $("#bjax-target").css("display","");
    var d = $("#bjax-target90").height();
    $("#bjax-target").animate({left:"0px"},"normal");
}


//显示diff image
function diffImage(){
    var obj = $('#imageDIVID').children();
    obj[0].style.display = '';
    obj[1].style.display = 'none';
    obj[2].style.display = 'none';
    $('#topDIVidx')[0].innerHTML = '<div style="display: block;float: left;width: 70px;margin-top: 4px ">Diff  Image</div>' +
        '<a  class="btn btn-s-xs btn-warning btn-rounded po2"  onclick="diffImage()">Diff</a>' +
        '<a  class="btn btn-s-xs btn-primary btn-rounded po2"  onclick="oldImage()">Old</a>' +
        '<a  class="btn btn-s-xs btn-success btn-rounded po2"  onclick="newImage()">New</a>' +
        '<a  class="pull-right po2" onclick="controlTOInfo()" style="margin-bottom: 10px" title="back"><i class="icon-arrow-left i-lg  inline"  id="refresh"></i></a>';

}


//显示old image
function oldImage(){
    var obj = $('#imageDIVID').children();
    obj[0].style.display = 'none';
    obj[1].style.display = '';
    obj[2].style.display = 'none';
    $('#topDIVidx')[0].innerHTML = '<div style="display: block;float: left;width: 70px;margin-top: 4px ">Old  Image</div>' +
        '<a  class="btn btn-s-xs btn-warning btn-rounded po2"  onclick="diffImage()">Diff</a>' +
        '<a  class="btn btn-s-xs btn-primary btn-rounded po2"  onclick="oldImage()">Old</a>' +
        '<a  class="btn btn-s-xs btn-success btn-rounded po2"  onclick="newImage()">New</a>' +
        '<a  class="pull-right po2" onclick="controlTOInfo()" style="margin-bottom: 10px" title="back"><i class="icon-arrow-left i-lg  inline"  id="refresh"></i></a>';

}


//显示new image
function newImage(){
    var obj = $('#imageDIVID').children();
    obj[0].style.display = 'none';
    obj[1].style.display = 'none';
    obj[2].style.display = '';
    $('#topDIVidx')[0].innerHTML = '<div style="display: block;float: left;width: 70px;margin-top: 4px ">New  Image</div>' +
        '<a  class="btn btn-s-xs btn-warning btn-rounded po2"  onclick="diffImage()">Diff</a>' +
        '<a  class="btn btn-s-xs btn-primary btn-rounded po2"  onclick="oldImage()">Old</a>' +
        '<a  class="btn btn-s-xs btn-success btn-rounded po2"  onclick="newImage()">New</a>' +
        '<a  class="pull-right po2" onclick="controlTOInfo()" style="margin-bottom: 10px" title="back"><i class="icon-arrow-left i-lg  inline"  id="refresh"></i></a>';

}


//控制切换图片
function switchImagePre(){
    if(image_num==0){
        image_num = 2;
    }else{
        --image_num;
    }
    var obj = $('#imageDIVID').children();
    for(var i=0;i<3;i++){

        if(i==image_num){
            obj[i].style.display = '';
        }else{
            obj[i].style.display = 'none';
        }
    }
    switch(image_num){
        case 0:$('#topDIVidx')[0].innerHTML = 'Diff  Image<a href="#" class="btn btn-s-xs btn-primary btn-rounded"  onclick="switchImagePre()">Previous</a><a href="#" class="btn btn-s-xs btn-success btn-rounded "  onclick="switchImageNext()">Next</a>';
            break;
        case 1:$('#topDIVidx')[0].innerHTML = 'Pre  Image<a href="#" class="btn btn-s-xs btn-primary btn-rounded"  onclick="switchImagePre()">Previous</a><a href="#" class="btn btn-s-xs btn-success btn-rounded "  onclick="switchImageNext()">Next</a>';
            break;
        case 2:$('#topDIVidx')[0].innerHTML = 'Now  Image<a href="#" class="btn btn-s-xs btn-primary btn-rounded"  onclick="switchImagePre()">Previous</a><a href="#" class="btn btn-s-xs btn-success btn-rounded "  onclick="switchImageNext()">Next</a>';
            break;
        default :break;
    }
}


//控制切换图片
function switchImageNext(){
    if(image_num==2){
        image_num = 0;
    }else{
        ++image_num;
    }
    var obj = $('#imageDIVID').children();
    for(var i=0;i<3;i++){

        if(i==image_num){
            obj[i].style.display = '';
        }else{
            obj[i].style.display = 'none';
        }
    }
    switch(image_num){
        case 0:$('#topDIVidx')[0].innerHTML = 'Diff  Image<a href="#" class="btn btn-s-xs btn-primary btn-rounded"  onclick="switchImagePre()">Previous</a><a href="#" class="btn btn-s-xs btn-success btn-rounded "  onclick="switchImageNext()">Next</a>';
            break;
        case 1:$('#topDIVidx')[0].innerHTML = 'Pre  Image<a href="#" class="btn btn-s-xs btn-primary btn-rounded"  onclick="switchImagePre()">Previous</a><a href="#" class="btn btn-s-xs btn-success btn-rounded "  onclick="switchImageNext()">Next</a>';
            break;
        case 2:$('#topDIVidx')[0].innerHTML = 'Now  Image<a href="#" class="btn btn-s-xs btn-primary btn-rounded"  onclick="switchImagePre()">Previous</a><a href="#" class="btn btn-s-xs btn-success btn-rounded "  onclick="switchImageNext()">Next</a>';
            break;
        default :break;
    }
}


//控制删除一个已存在的project对话框
function controlDelMenue(obj){
    $('#P_del_project_name').text(obj);
    selectProjectName = obj;
    var he = $('header').height()-26;
    var wi = document.body.clientWidth/2-150;
    $("#menuDIV_attribute2").css("left",wi+"px");
    $("#menuDIV_attribute2").css("display","");
    $("#menuDIV_attribute2").animate({top:"-47px"},"normal");
}


//设置maindiv的高度
function setDIVHeight(){
    var he = document.body.clientHeight;
//    var header = $('header').height();
    var header = 0;
    var header2 = $('h2').height();
    var header3 = $('footer').height();
    var x = he-header-header2-80;
//    x = he;
//    console.log(x);
    $("#div1").css("height",x+"px");
    $("#div190").css("height",x+"px");
    $("#div2").css("height",x+"px");
    $("#div3").css("height",x+"px");
//    console.log(header3);
    var xm2 = document.body.clientWidth;
    var xm0 = $('#sidebar2').width();
    var xm1 = $('#nav').width();
    var r = xm2 - xm0 - xm1;
    $("#bjax-target").css("width",r+"px");
    $("#bjax-target90").css("width",r+"px");
}

//控制添加url的menue
function controlURLMenue(obj){
    if(flagEdit){
        var name =  obj.parentNode.parentNode.children[1].innerText;
        var pageNew =  obj.parentNode.parentNode.children[2].innerText;
        var pageold =  obj.parentNode.parentNode.children[3].innerText;
        $('#needFix').text("需要修改的Page");
        $('#URL_input0').val(name);
        $('#URL_input').val(pageold);
        $('#URL_input2').val(pageNew);
        temp2pagename =name;
//        console.log(12);

    }else{
        $('#needFix').text("需要添加的Page");
        temp2pagename='-1#xcd#'

    }
//    var he = $('header').height()-26;
    var wi = document.body.clientWidth/2-150;
    $('#menuDIV_attribute').css("left",wi+"px");
    $("#menuDIV_attribute").css("display","");
    $("#menuDIV_attribute").animate({top:"-47px"},"normal");
}


//批量删除
function delUrlBySelect(){
    var obj = $('#main_table').children().children().find("input");

        var urlTemp = '';

        for(var i=1;i<obj.length;i++){
            if(obj[i].checked){
                urlTemp+= '"'+$('#main_table').children().children()[i].children[2].innerText +'",';
            }

        }
        urlTemp = urlTemp.substring(0,urlTemp.length-1);
        var str = '{"name":"'+selectProjectName+'","url":['+urlTemp+']}';
        var post_path = PATH + "delurl";

        $.get(post_path,
            str,
            function(call_data){
                if(call_data.status=='success'){
                    for(var j=obj.length-1;j>0;j--){
                        if(obj[j].checked){
                            $('#main_table').children().children()[j].remove();
                        }
                    }
                    obj[0].checked = false;
                }

            },
            'json'
        );

}


//批量选中
function selectAll(){
    var obj = $('#main_table').children().children().find("input");
    for(var i=1;i<obj.length;i++){
        if(obj[0].checked){
            obj[i].checked = true;
        }else{
            obj[i].checked = false;

        }
    }
}


//回到welcome
function returnWelcome(){
    document.getElementById('welcome').style.display = '';
    $("#exist_div_2").animate({left:"200000px"},"normal");
    $("#bjax-target").animate({left:"200000px"},"normal");
    $("#exist_div_3").animate({left:"200000px"},"normal");
    $("#bjax-target90").animate({left:"200000px"},"normal");
    document.getElementById('bjax-target').style.display = 'none';
    document.getElementById('exist_div_2').style.display = 'none';
    document.getElementById('exist_div_3').style.display = 'none';
    document.getElementById('bjax-target90').style.display = 'none';

}


//控制展示已添加product
function controlProductMenue(){
    returnWelcome();
    var d = $('#pro_product').children();
    for(var i=0;i< d.length;i++){
            d[i].className="list-group-item";
    }
    document.getElementById('sidebar2').style.display = '';

    $("#sidebar2").animate({left:"0px"},"normal");
    setTimeout(function(){    document.getElementById('sidebar2').style.zIndex = '0';
    },800);
}


//恢复左侧边栏
function huifuProdectMenue(){
    document.getElementById('sidebar2').style.zIndex = '-1';
    $("#sidebar2").animate({left:"-10000px"},"normal");
    document.getElementById('sidebar2').style.display = 'none';
    $("#bjax-target90").animate({left:"200000px"},"normal");
    $("#bjax-target90").css("display","none");

}


//修改product的对话框控制
function editProduct(obj){
    document.getElementById('proName_lable').style.display='none';
    //获取email信息
    var post_path = PATH + "getproject";
    var str = '';
    $.get(post_path,
        str,
        function(call_data){
            tempEmail=[];
            $.each(call_data.project,function(i,val){
                if(call_data.project[i].name==selectProjectName){
                    $.each(call_data.project[i].email,function(ii,vall){
                        tempEmail.push(call_data.project[i].email[ii]);
                    });
                }

            });


        },
        'json'
    );


    tempeditorProduct = obj;
//    console.log(obj.parentNode.parentNode.lastChild.lastChild.innerText);
    var productName = obj.parentNode.parentNode.lastChild.firstChild.firstChild.innerText;
    var desc = obj.parentNode.parentNode.lastChild.lastChild.innerText;
    editProjectNameTemp=productName;
    selectProjectName = productName;
    $('#URL_input3').val(productName);
    $('#URL_input4').val(desc);
    var he = -26;
    var wi = document.body.clientWidth/2-150;
    $('#menuDIV_attribute3').css("left",wi+"px");
    $("#menuDIV_attribute3").css("display","");
    $("#menuDIV_attribute3").animate({top:he+"px"},"normal");

}


//提交修改product信息
function submitEditProduct(){
    var hd = checkExistProjectNamefun();
    if(hd){

    var oldname = tempeditorProduct.parentNode.parentNode.lastChild.firstChild.firstChild.innerText;
    var olddesc = tempeditorProduct.parentNode.parentNode.lastChild.lastChild.innerText;
    var newname = $('#URL_input3').val();
    var newdesc = $('#URL_input4').val();
    var emailtt ='';
    $.each(tempEmail,function(j,vall){
        emailtt = emailtt +'"'+ vall + '",';
    });
    emailtt = emailtt.substring(0,emailtt.length-1);
    var str = '{"oldname":"'+selectProjectName+'","newname":"'+newname+'","desc":"'+newdesc+'","email":['+emailtt+']}';
//    console.log(str);
    var post_path = PATH + "editproject";
    $.get(post_path,
        str,
        function(call_data){
            if(call_data.status=='success'){
                tempeditorProduct.parentNode.parentNode.lastChild.firstChild.firstChild.innerText=newname;
                tempeditorProduct.parentNode.parentNode.lastChild.lastChild.innerText=newdesc;
                $("#menuDIV_attribute3").animate({top:"-2000px"},"slow");
                $('#URL_input3').val('');
                $('#URL_input4').val('');
            }

        },
        'json'
    );
    }

}


//查看history页面
function historyDiv(obj){
//    var name = obj.parentNode.parentNode.childNodes[1].innerText;
//    var pageNew = obj.parentNode.parentNode.childNodes[2].innerText;
//    var pageOld = obj.parentNode.parentNode.childNodes[3].innerText;
//    var str = '{"name":"'+name+'","urlold":"'+pageOld+'","urlnew":"'+pageNew+'"}';
//    console.log(str);

//    var pageNew = '';
//    var pageOld = '';
//    var bo = $('#main_table').children();
//    for(var i=0;i<bo.length;i++){
//        if(bo[i].childNodes[1].innerText==obj){
//            pageNew = bo[i].childNodes[2].innerText;
//            pageOld = bo[i].childNodes[3].innerText;
//            break;
//        }
//    }

//    console.log(obj);
    var pagename = obj;
    var str = '{"name":"'+selectProjectName+'","pagename":"'+pagename+'"}';
//    console.log(str);


    $('#main_table90').empty();
    var post_path = PATH + "getpagehistory";
    $.get(post_path,
        str,
        function(call_data){
            console.log(call_data);

            if(call_data.status=='success'){
//                for(var j=obj.length-1;j>0;j--){
//                    if(obj[j].checked){
//                        $('#main_table').children().children()[j].remove();
//                    }
//                }
//                obj[0].checked = false;
//                $.each(call_data.time,function(i,val){
                    for(var i = call_data.time.length-1;i>=0;i--){

                    $('#main_table90').append('<tr><td><label class="checkbox m-n i-checks">' +
                        '<input type="checkbox" name="post[]"><i></i>' +
                        '</label></td><td>'+pagename+'</td>' +
                        '<td>'+call_data.urlnew+'</td>' +
                        '<td>'+call_data.urlold+'</td>' +
                        '<td>'+resultrun(call_data.result[i])+'</td>' +
                        '<td>'+mmSecondTOtime(parseInt(call_data.time[i]),'yyyy/MM/dd HH:mm:ss')+'</td>' +
//        '<td>&nbsp;<a href="#" onclick="controlShowImage(this.parentNode.parentNode)"><i class="fa fa-file text-success text" title="view"></i></a></td>' +
                        '<td>&nbsp;<a class="po2" onclick="controlShowImage(this.parentNode.parentNode)">查看</a></td>' +
                        '</tr>');
                    }
//                });

            }

        },
        'json'
    );


    $("#bjax-target").animate({left:"200000px"},"slow");
    $("#bjax-target").css("display","none");
    $("#bjax-target90").css("display","");
    $("#bjax-target90").animate({left:"0px"},"slow");

}

//处理result
function resultrun(obj){
    console.log(typeof obj);
    if(obj==1){
        return "YES";
    }else{
        return "NO";
    }
}


//控制页面加载#
function onloadpage(){
    var x = window.location.href;
    var history = '';
    var x2 ='';
    if(x.indexOf('#')>0){
        x = x.substring(x.indexOf('#')+1, x.length);
        x2 = x;

        if(x.indexOf('&')>0){
            x2 = x.substring(0, x.indexOf('&'));
            history = x.substring(x.indexOf('&')+1, x.length);
        }

        if(x2.length>0){
            setDIVHeight();
            controlProductMenue();
            getProjectInfo(x2);

            var d = $('#pro_product').children();
            for(var i=0;i< d.length;i++){
                if(d[i].children[2].children[0].text==x2){
                    d[i].className="list-group-item active";
                    break;
                }

            }

            if(history.length>0){
                historyDiv(history);

            }

        }

    }

}


//增加配置邮箱界面
function controlEmailDIV(){
    if(email_temp.length!=0){

        for(var i = 0;i<email_temp.length;i++){
            if(i==0){
                $('#email1').val(email_temp[i]);
            }else{
                $("#submitBUtton2").before('<div class="form-group">' +
                    '<label class="col-lg-2 control-label">Email</label>' +
                    '<div class="col-lg-4" >' +
                    '<input type="text" class="form-control" value="'+email_temp[i]+'" placeholder="xxx@xxx" onblur="checkEmail(this)">' +
                    '<span class="help-block m-b-none" style="display: none" >不能为空或格式不正确</span>' +
                    '</div>' +
                    '<a href="#" class="pull-right " onclick="this.parentNode.remove()" style="margin-bottom: 10px">' +
                    '<i class="fa fa-trash-o i-lg  inline" style="margin-right: 20px" ></i>' +
                    '</a>' +
                    '</div>');
            }

        }

    }else{
        $('#email1').val('');
    }

    $("#addDIVx1").animate({left:"200000px"},"normal");
    document.getElementById('addDIVx1').style.display = "none";

    document.getElementById('addDIVx2').style.display = "";
    $("#addDIVx2").animate({left:"0px"},"normal");
    $('#addtipicon').attr("onclick","addEmail()");
    $('#addtipicon').attr("title","add email");

}


//恢复addproject div
function returnEmailDiv(){
    $("#addDIVx2").animate({left:"200000px"},"normal");
    document.getElementById('addDIVx2').style.display = "none";

    document.getElementById('addDIVx1').style.display = "";
    $("#addDIVx1").animate({left:"0px"},"normal");

    $('#addtipicon').attr("onclick","addURL()");
    $('#addtipicon').attr("title","add URL");

    var l = $('#add_project_table_2').children().length;
    if(l>1){
        var ob = $('#add_project_table_2').children();
        for(var i=1;i<l-1;i++){
            ob[i].remove();
        }
    }
    $('#email1').val('');
}


//save email
function saveEmail(){
    var flag = true;
    var obj1 = $("#add_project_table_2").children().children().find("input");
    $.each(obj1,function(i,val){
        if(!checkEmail(val)){
            flag = false;
        }

    });


    if(flag){

        email_temp=[];
        var obj = $("#add_project_table_2").children().children().find("input");
        $.each(obj,function(i,val){
            email_temp.push(val.value);

        });
        alert('保存成功');
        returnEmailDiv();
    }
}

//检查email的合法性
function checkEmail(obj){

        var email = obj.value;
        if(email==''||email==null||email.indexOf(' ')==0||email.indexOf('@')<0){

            obj.parentNode.children[1].style.display = '';
            obj.parentNode.className="col-lg-4 has-error";

            return false;
        }else{

            obj.parentNode.children[1].style.display = 'none';
            obj.parentNode.className="col-lg-4 has-success";

            return true;
        }
}

//切换编辑邮箱时的div
function switchDIV(str){
    if(str=="to"){
        if(tempEmail.length==0){
            $('#emailbutton').before('<div id="nonediv" class="col-md-12 services-grid ProductDIV2 ProductDIV234" style="display: none">' +
                '<div class="col-md-12 ">' +
                '<span style="text-align: center;margin-top: 20px">您还没有添加邮箱哦(⊙o⊙)哦</span>' +
                '</div>' +
                '</div>');
        }else{

            $.each(tempEmail,function(i,val){
                if(i>1){
                var d = $('#menuDIV_attribute3').height();
                $('#menuDIV_attribute3').height(d+33);
//                $('#menuDIV_attribute3').height(115);
                }
                $('#emailbutton').before('<div class="col-md-12 services-grid ProductDIV2 ProductDIV234" style="display: none">' +
                    '<div class="col-md-2 services-grid-left">' +
                    '<span style="text-align: center;margin-top: 20px">Email：</span>' +
                    '</div>' +
                    '<div class="col-md-8 services-grid-right">' +
                    '<input onblur="checkEmail2(this)" value="'+val+'" type="text" style="width: 100%;margin-bottom: 10px" size="200" >' +
                    '</div>' +
                    '<div onclick="delExistProjectEmail(this)" class="col-md-1 services-grid-left" style="padding: 0;margin: 0;">' +
                    '<i class="fa fa-trash-o po2" ></i>' +
                    '</div>' +
                    '<div class="col-md-1 services-grid-left" style="padding: 0;margin: 0;display: none">' +
                    '<i class="fa fa-times-circle text-danger" ></i>' +
                    '</div></div>');
            });
        }

        $('.ProductDIV').css('display','none');
        $('.ProductDIV2').css('display','');
        $('#emailaddicon').css('display','');

    }else{

    }
}

//取消邮箱编辑状态
function cancel(){
    $('#emailaddicon').css('display','none');
    $('.ProductDIV2').css('display','none');
    $('.ProductDIV').css('display','');
    $('.ProductDIV234').remove();
    $('#menuDIV_attribute3').animate({height:"200px"},'fast');
}

//addeamin 再修改proect页面
function addeEmailExistProject(){
    if($('#menuDIV_attribute3').height()<596){
        var d = $('#menuDIV_attribute3').children();
    if(d.length==9&&$('#menuDIV_attribute3').children()[6].id=='nonediv'){
        $('#nonediv').remove();

    }
        var d2 = $('#menuDIV_attribute3').children();
            if(d2.length>9){
                var d = $('#menuDIV_attribute3').height();
                $('#menuDIV_attribute3').height(d+33);
            }

            $('#emailbutton').before('<div class="col-md-12 services-grid ProductDIV2 ProductDIV234" style="">' +
                '<div class="col-md-2 services-grid-left">' +
                '<span style="text-align: center;margin-top: 20px">Email：</span>' +
                '</div>' +
                '<div class="col-md-8 services-grid-right">' +
                '<input onblur="checkEmail2(this)" value="" type="text" style="width: 100%;margin-bottom: 10px" size="200" >' +
                '</div>' +
                '<div onclick="delExistProjectEmail(this)" class="col-md-1 services-grid-left" style="padding: 0;margin: 0;">' +
                '<i class="fa fa-trash-o po2" ></i>' +
                '</div>' +
                '<div class="col-md-1 services-grid-left" style="padding: 0;margin: 0;display: none">' +
                '<i class="fa fa-times-circle text-danger" ></i>' +
                '</div></div>');


}

}

//保存邮箱内容
function saveEmailinfo(){
    var d = $('#menuDIV_attribute3').children();
    var yu = true;
    if(d.length==9&&$('#menuDIV_attribute3').children()[6].id=='nonediv'){
        tempEmail = [];
    }else{
        for(var i=6;i< d.length-2;i++){
            var x = d[i].children[1];
            if(!checkEmail2(x.children[0])){
                yu = false;
            }
        }
        if(yu){
            tempEmail = [];
            for(var i=6;i< d.length-2;i++){
                var x = d[i].children[1];
                tempEmail.push(x.children[0].value)
            }
        }
    }
    if(yu){
        cancel();
    }
}

//删除已添加的email
function delExistProjectEmail(obj){
    obj.parentNode.remove();
    var d = $('#menuDIV_attribute3').children();
    if(d.length>10){
        var d2 = $('#menuDIV_attribute3').height();
        $('#menuDIV_attribute3').height(d2-33);
    }
    if(d.length==8){
        $('#emailbutton').before('<div id="nonediv" class="col-md-12 services-grid ProductDIV2 ProductDIV234" style="">' +
            '<div class="col-md-12 ">' +
            '<span style="text-align: center;margin-top: 20px">您还没有添加邮箱哦(⊙o⊙)哦</span>' +
            '</div>' +
            '</div>');
    }

}

//检查email的合法性
function checkEmail2(obj){
    var email = obj.value;
    if(email==''||email==null||email.indexOf(' ')==0||email.indexOf('@')<0){
        obj.parentNode.parentNode.children[3].style.display = '';
        return false;
    }else{
        obj.parentNode.parentNode.children[3].style.display = 'none';
        return true;
    }
}

//检查修改project时候的的重名问题
function checkExistProjectNamefun(){
    var obj = $('#URL_input3').val();
    if(obj==''||obj==null||obj.indexOf(' ')==0){
        document.getElementById('proName_lable').style.display='';
        return false;
    }
    var x = $('#pro_product').children();
    for(var i=0;i< x.length;i++){
        var name = $('#pro_product').children()[i].children[2].children[0].children[0].innerText;
        if(name!=editProjectNameTemp&&name==obj){
            document.getElementById('proName_lable').style.display='';
            return false;
        }
    }
    document.getElementById('proName_lable').style.display='none';
    return true;
}

//控制触发所有构建
function buildAll(){
    if($('#div1').find('input')[0].checked){
        //构建全部
        var str = '{"name":"'+selectProjectName+'"}';
//    console.log(str);

        var post_path = PATH + "execution";
        $.get(post_path,
            str,
            function(call_data){

                if(call_data.status=='success'){
                    alert("已成功触发构建所选page");
                }

            },
            'json'
        );

    }else{
        var flp = false;
        for(var i = 0;i<$('#div1').find('input').length;i++){
            if($('#div1').find('input')[i].checked){
                flp = true;
                break;
            }
        }

        if(flp){
            //构建部分
            var pagename = '';

            for(var i = 1;i<$('#div1').find('input').length;i++){
                if($('#div1').find('input')[i].checked){
                    var x = $('#div1').find('tr')[i];
                    var t = x.getElementsByTagName('td')[1].innerText;
                    pagename = pagename + '"'+t+'",';
                }
            }
            pagename = pagename.substring(0,pagename.length-1);
            var str = '{"name":"'+selectProjectName+'","pagename":['+pagename+']}';
//            console.log(str);
            var post_path = PATH + "executionsome";
            $.get(post_path,
                str,
                function(call_data){

                    if(call_data.status=='success'){
                        alert("已成功触发构建所选page");
                    }

                },
                'json'
            );
        }else{
            alert("请勾选要触发构建的page!");
        }
    }
}

//编辑selectors
function editSelectors(obj){
    var x = window.event.srcElement;
    pagenameTemp2 = x;
    var num = x.parentNode.parentNode.parentNode.rowIndex;
//    console.log(includeSelectors_temp[num-1].excludeSelectors);

    if(includeSelectors_temp[num-1].excludeSelectors==null){
        $('#URL_input55').val('');
        $('#URL_input66').val('');
    }else{
        var strtemp='';
        for(var i = 0;i<includeSelectors_temp[num-1].excludeSelectors.length;i++){
            strtemp+= includeSelectors_temp[num-1].excludeSelectors[i]+',';
        }
        strtemp = strtemp.substring(0,strtemp.length-1);
        $('#URL_input55').val(strtemp);


        var strtemp2='';
        for(var i = 0;i<includeSelectors_temp[num-1].includeSelectors.length;i++){
            strtemp2+= includeSelectors_temp[num-1].includeSelectors[i]+',';
        }
        strtemp2 = strtemp2.substring(0,strtemp2.length-1);
        $('#URL_input66').val(strtemp2);
    }

    var wi = document.body.clientWidth/2-150;
    $('#menuDIV_attribute4').css("left",wi+"px");
    $("#menuDIV_attribute4").css("display","");
    $("#menuDIV_attribute4").animate({top:"-47px"},"normal");


}

//保存修改后的selector信息
function sendSelectorInfo(){
    var x = pagenameTemp2.parentNode.parentNode.parentNode
    var pagename = x.getElementsByTagName('td')[1].innerText;

    var urlTemp3 = $('#URL_input55').val();
    var urlTemp4 = $('#URL_input66').val();
    if(urlTemp3.indexOf(",")>0){
        var arr = new Array();
        arr = urlTemp3.split(",");
        urlTemp3='';
        for(var i=0;i<arr.length;i++){
            urlTemp3+='"'+arr[i]+'",';
        }
        urlTemp3 = urlTemp3.substring(0,urlTemp3.length-1);
    }else{
        if(!urlTemp3==''){
            urlTemp3 = '"'+urlTemp3+'"';
        }

    }
    if(urlTemp4.indexOf(",")>0){
        var arr = new Array();
        arr = urlTemp4.split(",");
        urlTemp4='';
        for(var i=0;i<arr.length;i++){
            urlTemp4+='"'+arr[i]+'",';
        }
        urlTemp4 = urlTemp4.substring(0,urlTemp4.length-1);
    }else{
        if(!urlTemp4==''){
            urlTemp4 = '"'+urlTemp4+'"';
        }

    }
    var str = '{"name":"'+selectProjectName+'","pagename":"'+pagename+'","excludeSelectors":['+urlTemp3+'],"includeSelectors":['+urlTemp4+']}';
    var post_path = PATH + "editpage";
    console.log(str);
    $.get(post_path,
        str,
        function(call_data){
//            console.log(call_data);
            if(call_data.status=='success'){
                $("#menuDIV_attribute4").animate({top:"-2000px"},"slow");
                $('#URL_input55').val('');
                $('#URL_input66').val('');
                refreshSelectors(selectProjectName);

            }

        },
        'json'
    );
}